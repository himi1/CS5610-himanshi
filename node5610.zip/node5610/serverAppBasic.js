﻿var express = require('express');
var app = express();

app.get('/', function (req, res) {
    res.send('Hello World');
});

app.get('/bye', function (req, res) {
    res.send('Good Bye');
});

app.get('/content', function (req, res) {
    res.send('Hello from nodejs');
});

app.listen(3000);