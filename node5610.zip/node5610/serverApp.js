﻿var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var multer = require('multer');

app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded
app.use(multer()); // for parsing multipart/form-data

//app.get('/', function (req, res) {
//    res.send('Hello nothing');
//});

var alice = {username: "alice", password: "wonderland"}

var developers = [
    {
        firstName: "Alice", lastName: "Wonderland", application: [
          { name: "Word" },
          { name: "Excel" },
          { name: "Powerpoint" },
        ]
    },
    { firstName: "Alice", lastName: "Wonderland", application: [] },
    { firstName: "Alice", lastName: "Wonderland", application: [] },
    { firstName: "Alice", lastName: "Wonderland", application: [] }
]

app.post("/developer", function (req, res) {
    var obj = req.body; //{ firstName: "First", lastName: "Last" };
    developers.push(obj);
    res.json(developers);
});

app.delete("/developer/:id", function (req, res) {
    var index = req.params.id;
    developers.splice(index, 1);
    res.json(developers);
});

app.put("/developer/:id", function (req, res) {
    var index = req.params.id;
    developers[req.params.id] = req.body;
    res.json(developers);
});

app.get("/alice", function (req, res) {
    res.json(alice);
});

app.get("/developer", function (req, res) {
     res.json(developers);
});

app.get("/developer/:index", function (req, res) {
    var indx = req.params.index; // or req.params['index'] "to map"
    res.json(developers[indx]);
});

app.get("/developer/:index/application", function (req, res) {
    var indx = req.params.index; // or req.params['index'] "to map"
    res.json(developers[indx].application);
});

app.get("/developer/:index/application/:appIndex", function (req, res) {
    var indx = req.params.index; // or req.params['index'] "to map"
    var aindx = req.params.appIndex;
    res.json(developers[indx].application[aindx]);
});



app.use(express.static(__dirname + '/public'));

app.listen(3000);